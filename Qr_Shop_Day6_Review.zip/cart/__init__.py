"""Shopping cart app package."""
